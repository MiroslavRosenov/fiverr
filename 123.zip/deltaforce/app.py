import logging
import time
import httpx
import base64
import json
import pandas as pd

from bs4 import BeautifulSoup
from typing import List, Optional
from dataclasses import dataclass, field

@dataclass
class Customer:
    name: str
    pin: int
    client_id: int
    billingStatus: str
    address: Optional[str] = field(default_factory=str)
    phone_number: Optional[str] = field(default_factory=str)
    cross_sale: Optional[str] = field(default_factory=str)
    
@dataclass
class User:
    username: str
    password: str
    token: str

BASE_FORMATTER = logging.Formatter(
    "%(asctime)s ::[%(levelname)s]:: %(message)s"
)

class Logging(logging.Logger):
    def __init__(self, name: str, level=logging.INFO) -> None:
        handler = logging.StreamHandler()
        handler.setFormatter(BASE_FORMATTER)
        super().__init__(name, level)
        self.addHandler(handler)
    
class Scrapper:
    def __init__(self) -> None:
        self.log = Logging(__name__, logging.DEBUG)
        self.users: List[User] = []
        self.session = httpx.Client(timeout=httpx.Timeout(None))
        
        with open("config.json", encoding="utf-8") as f:
            data: dict = json.load(f)

            for i in data.items():
                if not (username := i[1].get("username")) or not (password := i[1].get("password")):
                    continue 
                
                if (resp := self.session.post(
                    f"https://deltaforce.vivacom.bg/api/delta-force-user/token?username={username}&password={base64.b64encode(password.encode('ascii')).decode('ascii')}",
                    headers={
                        "Origin": "https://deltaforce.vivacom.bg",
                        "Referer": "https://deltaforce.vivacom.bg",
                    }
                )).status_code == 200:
                    try:
                        data = resp.json()
                    except json.decoder.JSONDecodeError as e:
                        soup = BeautifulSoup(resp.text, "lxml")
                        self.log.error(f"Failed to login into {username}:: {soup.text}")
                    else:
                        self.users.append(
                            User(username, password, f"Bearer {data['access_token']}")
                        )
                        self.log.info(f"Successfully logged into {username}:: {data['access_token']}")
                else:
                    self.log.error(f"Failed to login into {username}:: {resp}")
        
    def scrape(self, user: User, pin: str) -> Optional[Customer]:
        if (resp := self.session.get(
            f"https://deltaforce.vivacom.bg/api/delta-force-user/search?searchSpec={pin}&filterBy=IDENTITY_NUMBER",
            headers={
                "Authorization": user.token
            }
        )).status_code != 200:
            return self.log.error(resp)
        
        try:
            data: dict = resp.json()
        except json.decoder.JSONDecodeError as e:
            soup = BeautifulSoup(resp.text, "lxml")
            return self.log.error(f"Failed get info about {pin}:: {soup.text}")
        
        customer = Customer(
            " ".join([data.get("firstName", "-"), data.get("middleName", "-"), data.get("companyLastName", "-")]),
            data["identityNumber"],
            data["customerCode"],
            data["billingStatus"],
            " ".join((dict(
                sorted(
                    dict(filter(lambda x: x[0] not in ["eknm", "notes", "blockFlat", "externalId", "floor"], data.get("primaryAddress", {}).items())).items(),
                    key=lambda a: a[0] not in ["country", "postalCode", "townType", "townName", "streetType", "streetName"]
                )
            )).values()),
            data.get("telephoneNumber")
        )
        
        if (resp := self.session.get(
            f"https://deltaforce.vivacom.bg/api/delta-force-offer/offers/retention-and-information?customerCode={customer.client_id}",
            headers={
                "Authorization": user.token
            }
        )).status_code == 200:
            information = resp.json()
            
            if (cross := information.get("Cross sell")):
                customer.cross_sale = ", ".join([x["offerName"] for x in cross[0].get("offers", [])])
            
        else: #data
            information = {}
        
        if (resp := self.session.get(
            f"https://deltaforce.vivacom.bg/api/delta-force-offer/offers/active?customerCode={customer.client_id}",
            headers={
                "Authorization": user.token
            }
        )).status_code == 200:
            for b, service in enumerate(resp.json()):
                setattr(customer, f"{str(b).zfill(2)}.service_name", service["productNameBUL"])
                setattr(customer, f"{str(b).zfill(2)}.service_number", service["serviceId"])
                setattr(customer, f"{str(b).zfill(2)}.plan", ", ".join(x["productNameBUL"] for x in service.get("children", [])))
                setattr(customer, f"{str(b).zfill(2)}.MRC", service["price"])
                setattr(customer, f"{str(b).zfill(2)}.service_level", service["serviceIdLevelAmount"])
                setattr(customer, f"{str(b).zfill(2)}.end_date", service["contractPeriodEndDate"])
                setattr(customer, f"{str(b).zfill(2)}.retention", "")
                setattr(customer, f"{str(b).zfill(2)}.service_period", int(service["fmcContractTerms"]))
                setattr(customer, f"{str(b).zfill(2)}.account_number", service["billingAccountCode"])
                setattr(customer, f"{str(b).zfill(2)}.service_address", service.get("address"))
                setattr(customer, f"{str(b).zfill(2)}.promotion", service.get("prodPromId"))
                
                for y in information.get("Retention", []):
                    if y["serviceId"] == service["serviceId"]:
                        setattr(customer, f"{str(b).zfill(2)}.retention", ", ".join([x["offerName"] for x in y.get("offers", [])]))
                
        return customer

if __name__ == "__main__":
    app = Scrapper()
    frames = []
    
    with open("input.txt") as f:
        pins = [int(x) for x in f.read().split("\n")]
    
    while len(pins) > 0:
        if not app.users:
            raise RuntimeError("There must be at least ONE user to work with! Try to login in 5 minutes")
        
        for i in app.users:
            try:
                pin = pins.pop(0)
            except IndexError:
                break
            
            app.log.info(f"Working on {i.username}:: {pin}")
            if frame := app.scrape(i, pin):
                frames.append(frame.__dict__)

            time.sleep(6)
    
    x = pd.DataFrame(frames)
    
    while True:
        try:
            x.to_excel("export.xlsx", index=False)
        except PermissionError:
            app.log.warning("Can't write to 'export.xlsx'! Trying again in 5 seconds")
            time.sleep(5)
        else:
            break