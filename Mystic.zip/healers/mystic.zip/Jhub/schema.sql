CREATE TABLE channels (
    guild_id BIGINT NOT NULL,
    channel_id BIGINT NOT NULL,
    repo_name TEXT,
    PRIMARY KEY (guild_id, channel_id)
);

CREATE TABLE logs (
    file_name TEXT NOT NULL,
    repo_name TEXT NOT NULL,
    sha TEXT NOT NULL,
    created_at TIMESTAMP NOT NULL,
    PRIMARY KEY (file_name, repo_name)
);


CREATE TABLE updates (
    origin BIGINT NOT NULL,
    target BIGINT NOT NULL,
    PRIMARY KEY (origin, target)
);