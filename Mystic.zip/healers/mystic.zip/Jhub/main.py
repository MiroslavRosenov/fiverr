import os
import github
import discord
import logging
import aiohttp

from typing import Any
from typing import Optional
from discord.ext import commands

logger = logging.getLogger(__name__)

class Bot(commands.AutoShardedBot):
    def __init__(self) -> None:
        intents = discord.Intents.all()
        intents.typing = False

        super().__init__(
            command_prefix="$",
            intents=intents,
            case_insensitive=True
        )

        self.session: Optional[aiohttp.ClientSession] = None
        self.github = github.Auth.Token(os.getenv("GITHUB_TOKEN"))
        self.tree.error(self.on_app_error)

    async def on_app_error(self, interaction: discord.Interaction, error: Any) -> None:
        return self.dispatch("app_command_error", interaction, error)

    @property
    def color(self) -> discord.Color:
        return 0xFFFFFF
    
    @property
    def log_channel(self) -> Optional[discord.TextChannel]:
        if not self.is_ready():
            return None
        return self.get_channel(1119047072629411840)

    async def setup_hook(self) -> None:
        for cog in os.listdir("./cogs"):
            if cog.endswith(".py"):
                try:
                    await self.load_extension(f"cogs.{cog.removesuffix('.py')}")
                except Exception as e:
                    logger.critical(f"Failed to load extension {cog!r}!", exc_info=e)
                else:
                    logger.info(f"Successfully load extention {cog!r}!")

        await self.load_extension("jishaku")

    async def on_ready(self) -> None:
        logger.info(f"Logged in as {self.user.name} (ID: {self.user.id})")