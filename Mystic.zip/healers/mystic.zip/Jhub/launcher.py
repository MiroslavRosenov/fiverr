import os
import asyncio
import dotenv
import discord
import aiohttp

from main import Bot

dotenv.load_dotenv()

async def run_bot():
    async with aiohttp.ClientSession() as session:
        async with Bot() as bot:
            bot.session = session
            await bot.start(os.getenv("TOKEN")) #type: ignore

if __name__ == '__main__':
    discord.utils.setup_logging()
    asyncio.run(run_bot())