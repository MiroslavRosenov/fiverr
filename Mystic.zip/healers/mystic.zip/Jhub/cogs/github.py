import re
import io
import time
import discord
import github
import sqlite3
import contextlib

from main import Bot

from discord.ext import menus
from discord.ext import commands
from typing import List, Union

from contextlib import closing
from pathvalidate import sanitize_filepath
from github.ContentFile import ContentFile


ALLOWED_TYPES = (
    ".iss",
    ".aa", 
    ".xml",
    ".zip"
)

class Menu(menus.ListPageSource):
    def __init__(self, data):
        super().__init__(data, per_page=5)

    async def format_page(self, menu, entries):
        offset = menu.current_page * self.per_page
        return '\n'.join(f'{i+1}:: {v}' for i, v in enumerate(entries, start=offset))

class GitHub(commands.Cog):
    def __init__(self, bot: Bot) -> None:
        self.bot = bot
    
    async def log(self, title: str, description: str, user: discord.User) -> None:
        embed = discord.Embed(
            title=title,
            description=description,
            color=self.bot.color
        )\
            .set_footer(
                text=f"Executed by {str(user)}",
                icon_url=user.display_avatar.url
            )
        
        if channel := self.bot.log_channel:
            await channel.send(embed=embed)
    
    @commands.guild_only()
    @commands.command(description="Set a GitHub upload channel.")
    async def setchannel(self, ctx: commands.Context, channel: discord.TextChannel) -> None:
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as cur:
                query = "INSERT INTO channels(guild_id, channel_id) VALUES (?, ?)"
                try:
                    cur.execute(query, (ctx.guild.id, channel.id))
                    con.commit()
                except sqlite3.IntegrityError:
                    return await ctx.send(":warning: That channel is already added!")
            
        await ctx.send(":white_check_mark: Channel has been changed successfully!")
        await self.log("New Channel Set", f"Channel: {channel.mention}", ctx.author)

    @commands.guild_only()
    @commands.command(description="Creates a GitHub repository.")
    async def createrepo(self, ctx: commands.Context, name: str) -> None:
        try:
            repo = github.Github(self.bot.github.token).get_user().create_repo(name)
            await ctx.send(f":white_check_mark: The repo has been created successfully:: {repo.html_url}")
            await self.log("New Respository Created", f"Repository: {repo.name}", ctx.author)
        
        except github.GithubException:
            await ctx.send(":warning: This repo name is already taken!")

    @commands.guild_only()
    @commands.command(description="Sets a github repository for this server")
    async def setrepo(self, ctx: commands.Context, name: str) -> None:
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as c:
                query = "SELECT * FROM channels WHERE guild_id = ?"
                c.execute(query, (ctx.guild.id,))
                
                if not (c.fetchone()):
                    return await ctx.send(":warning: This server does not have selected channel, please select one with the `$setchannel` command!")
            
                try:
                    repo = github.Github(self.bot.github.token).get_user().get_repo(name)
                    await ctx.send(f":white_check_mark: `{repo.name}` has been selected as the default repo for this server.")
                    
                    query = "UPDATE channels SET repo_name = ? WHERE guild_id = ? AND channel_id = ?"
                    c.execute(query, (name, ctx.guild.id, ctx.channel.id))
                    con.commit()
                except github.UnknownObjectException:
                    await ctx.send(":warning: The repo was not found, please create one with the `$createrepo` command!")

    @commands.command()
    async def searchfiles(self, ctx: commands.Context, *files: str) -> None:
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as c:
                query = "SELECT * FROM channels WHERE guild_id = ? and channel_id = ?"
                c.execute(query, (ctx.guild.id, ctx.channel.id))
                
                if not (data := c.fetchone()):
                    return await ctx.send(
                        ":warning: There isn't an repo set to this channel!"
                    )
        try:
            repo = github.Github(self.bot.github.token).get_user().get_repo(data[2])
            content: List[ContentFile] = repo.get_contents("/")
            
            def extract(content: List[ContentFile]):
                extracted: List[ContentFile] = []
                to_do: List[ContentFile] = []
                
                for f in content:
                    if f.type != "dir":
                        extracted.append(f)
                    else:
                        to_do.extend(repo.get_contents(f.path))
                
                if to_do:
                    extracted.extend(extract(to_do))
                return extracted
            
            if found := [x for x in extract(content) if x.name in files]:
                for x in found:
                    url = f"https://raw.githubusercontent.com/{repo.full_name}/{repo.default_branch}/{x.path}"
                    fp = await (await self.bot.session.get(url)).read()
                    await ctx.send(url, file=discord.File(io.BytesIO(fp), filename=x.path))
            else:
                return await ctx.send(":warning: The requested file was not found in this repository!")
        except github.UnknownObjectException:
            await ctx.send(":warning: The repo was not found, please create one with the `$createrepo` command!")
            
    @commands.command()
    async def searchrepo(self, ctx: commands.Context, name: str) -> None:
        try:
            repo = github.Github(self.bot.github.token).get_user().get_repo(name)
            await ctx.send(repo.html_url)
        except github.UnknownObjectException:
            await ctx.send(":warning: The repo was not found, you create one with the `$createrepo` command.")
    
    @commands.command(description="Get the recend github uploads")
    async def recentuploads(self, ctx: commands.Context) -> None:
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as c:
                c.execute("SELECT * FROM logs ORDER BY created_at DESC")
                
                if not (logs := c.fetchall()):
                    return await ctx.send(f":warning: There aren't any recent uploads!")
                
                pages = menus.MenuPages(source=Menu([f"{github.Github(self.bot.github.token).get_user().get_repo(x[1]).html_url} -> {discord.utils.remove_markdown(x[0])}" for x in logs]))
                await pages.start(ctx)
    
    @commands.guild_only()
    @commands.command(description="Creates new connection for the current channel.")
    async def updatepls(self, ctx: commands.Context, target: Union[discord.TextChannel, int]) -> None:
        if not (channel := self.bot.get_channel(getattr(target, "id", target))):
            return await ctx.send(":warning: The desired channel was not found!")
        
        if ctx.channel == channel:
            return await ctx.send(":warning: You can't create links to the same channel!")
        
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as c:
                try:
                    query = "INSERT INTO updates VALUES (?, ?)"
                    c.execute(query, (ctx.channel.id, channel.id))
                except sqlite3.IntegrityError:
                    return await ctx.send(f":warning: {channel.mention} is already linked to {ctx.channel.mention}!")
                else:
                    con.commit()
        
        await ctx.send(f":white_check_mark: Successfully linked {ctx.channel.mention} to {channel.mention}!")
    
    @commands.guild_only()
    @commands.command(description="Removes all connection to this channels.")
    async def donotupdatepls(self, ctx: commands.Context) -> None:
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as c:
                c.execute("SELECT * FROM updates WHERE origin = ?", (ctx.channel.id,))
                if not c.fetchone():
                    return await ctx.send(f":warning: There aren't any channels that are linked to {ctx.channel.mention}!")
                
                c.execute("DELETE FROM updates WHERE origin = ?", (ctx.channel.id,))
                con.commit()
        
        await ctx.send(f":white_check_mark: Successfully removed all links for this channel!")

    @commands.Cog.listener("on_message")
    async def on_message(self, message: discord.Message) -> None:
        if not (guild := message.guild) or message.author.bot:
            return
        
        if "Topic Updated = [ISXEQ2]" in message.content:
            with closing(sqlite3.connect("database.db")) as con:
                with closing(con.cursor()) as c:
                    c.execute("SELECT * FROM updates WHERE origin = ?", (message.channel.id,))
                    
                    for x in c.fetchall():
                        with contextlib.suppress(discord.HTTPException):
                            await self.bot.get_channel(x[1]).send(message.content)
        
        if not message.attachments:
            return
        
        with closing(sqlite3.connect("database.db")) as con:
            with closing(con.cursor()) as c:
                query = "SELECT * FROM channels WHERE guild_id = ? and channel_id = ?"
                c.execute(query, (guild.id, message.channel.id))
                
                if not (data := c.fetchone()):
                    return
            
                if (files := [f for f in message.attachments if f.filename.endswith(ALLOWED_TYPES)]):
                    try:
                        repo = github.Github(self.bot.github.token).get_user().get_repo(data[2])
                    except github.UnknownObjectException:
                        return await message.reply(
                            ":warning: Repo is unavailable, maybe it got deleted?"
                        )
                    else:
                        for f in files:
                            name = f.filename.lower()
                            
                            tanks = r"paladin|shadowknight|bruiser|monk|guardian|berserker"
                            healers = r"channeler|defiler|mystic|warden|fury|inquisitor|inq|templar"
                            scouts = r"beastlord|bl|brigand|swashbuckler|ranger|assassin|troubador|troub|dirge"
                            mages = r"coercer|illusionist|conjuror|conj|necromancer|wizard|warlock"
                            
                            if re.search(tanks, name):
                                path = sanitize_filepath(f"tanks/{name}")
                            elif re.search(healers, name):
                                path = sanitize_filepath(f"healers/{name}")
                            elif re.search(scouts, name):
                                path = sanitize_filepath(f"scouts/{name}")
                            elif re.search(mages, name):
                                path = sanitize_filepath(f"mages/{name}")
                            else:
                                path = sanitize_filepath(name)
                            
                            if (sub := f.filename.split("-")):
                                path = sanitize_filepath(sub[0] + "/" + path)
                            
                            query = "SELECT * FROM logs WHERE file_name = ? AND repo_name = ?"
                            c.execute(query, (f.filename, data[2]))
                            
                            if (old := c.fetchone()):
                                new_branch =  f"update-{time.time()}"
                                branch = repo.get_branch(repo.default_branch)
                                repo.create_git_ref(ref=f"refs/heads/{new_branch}", sha=branch.commit.sha)
                                
                                resp = repo.update_file(path, "Committing files", await f.read(), old[2], branch=new_branch) 
                                query = "UPDATE logs SET created_at = ? WHERE file_name = ? AND repo_name = ?"
                                c.execute(query, (discord.utils.utcnow(), f.filename, data[2]))
                                
                                repo.create_pull(title=f"Update {f.filename}", body=f"Proposing changes to {f.filename}", head=new_branch, base=branch.name)
                            else:
                                resp = repo.create_file(path, "Committing files", await f.read())
                                query = "INSERT INTO logs VALUES (?, ?, ?, ?)"
                                c.execute(query, (f.filename, data[2], resp["content"].sha, discord.utils.utcnow()))
                            
                            await message.reply(f"✅ File {f.filename!r} was successfully uploaded:: {discord.utils.escape_markdown(resp['content'].html_url)}")
            con.commit()
    
async def setup(bot: Bot):
    await bot.add_cog(GitHub(bot))